#ifndef CPU_KERNEL_DISPATCH_H_
#define CPU_KERNEL_DISPATCH_H_

#include <stdio.h>
#include <stdlib.h>
#include <utils/utils.h>

void* atender_cpu_kernel_dispatch(void* arg);

#endif