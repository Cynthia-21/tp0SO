#ifndef KERNEL_MEMORIA_H_
#define KERNEL_MEMORIA_H_

#include <stdio.h>
#include <stdlib.h>
#include <utils/utils.h>

void atender_kernel_memoria();

#endif