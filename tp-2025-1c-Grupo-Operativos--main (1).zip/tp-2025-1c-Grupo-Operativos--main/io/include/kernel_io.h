#ifndef KERNEL_IO_H_
#define KERNEL_IO_H_

#include <stdio.h>
#include <stdlib.h>
#include <utils/utils.h>


void atender_kernel_io(char* nombre_interfaz);

#endif