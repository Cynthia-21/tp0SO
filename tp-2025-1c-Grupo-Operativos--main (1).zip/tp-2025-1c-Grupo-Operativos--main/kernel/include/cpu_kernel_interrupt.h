#ifndef CPU_KERNEL_INTERRUPT_H_
#define CPU_KERNEL_INTERRUPT_H_

#include <stdio.h>
#include <stdlib.h>
#include <utils/utils.h>


void* atender_cpu_kernel_interrupt(void* arg);
// void registrar_cpu_conectado(char* cpu_id, int socket_cpu_interrupt);
// bool existe_cpu(char* cpu_id)
#endif