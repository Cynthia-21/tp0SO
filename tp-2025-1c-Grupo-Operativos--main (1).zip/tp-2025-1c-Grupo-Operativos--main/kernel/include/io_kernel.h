#ifndef IO_KERNEL_H_
#define IO_KERNEL_H_

#include <stdio.h>
#include <stdlib.h>
#include <utils/utils.h>


void* atender_io_kernel(void* arg);


#endif // IO_KERNEL_H_
