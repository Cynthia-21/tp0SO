#ifndef MEMORIA_CPU_H_
#define MEMORIA_CPU_H_

#include <stdio.h>
#include <stdlib.h>
#include <utils/utils.h>


void atender_memoria_cpu(t_log* cpu_logger);
#endif